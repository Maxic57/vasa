#!/usr/bin/env bash
# HiveOS runs this as a CHILD PROCESS via /hive/miners/custom/h-run.sh; its
# miner-run sets MINER_DIR / CUSTOM_MINER WITHOUT export, so they are empty
# here. Never rely on them: h-config.sh has already written the config file
# next to this script (in the parent shell), so use paths relative to $0.
cd "$(dirname "$0")" || exit 1

[[ -e quanpool.conf ]] && . ./quanpool.conf

# No TTY under HiveOS: force plain logging (the full-screen dashboard is skipped
# automatically off a TTY, but this is explicit and safe).
export MINER_NO_DASHBOARD=1

# shellcheck disable=SC2086  # QUANTUS_ARGS is a pre-built, intentionally-split arg line
exec ./quanpool-miner serve $QUANTUS_ARGS
