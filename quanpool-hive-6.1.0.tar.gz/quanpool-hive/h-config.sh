#!/usr/bin/env bash
# Build the miner argument line from the Flight Sheet, into $CUSTOM_CONFIG_FILENAME.
#
# Flight Sheet fields used:
#   Pool URL                         -> $CUSTOM_URL       (host:port of the pool/node)
#   Wallet and worker template       -> $CUSTOM_TEMPLATE  (<payout-address>.<worker>)
#   Extra config arguments           -> $CUSTOM_USER_CONFIG
#     Put the pool's TLS fingerprint here, e.g.
#       --tls-cert-sha256 87dc37af6096a3ddc860b94368ca087775f3ad3e0c4e9bcff3b07ea08d8abef6
#     plus any of: --gpu-devices N  --cpu-workers 0  --gpu-batch-size ...
#
# The metrics port is fixed at 9900 so h-stats.sh can read /hive-stats.

[[ -z $CUSTOM_CONFIG_FILENAME ]] && return 1
mkdir -p "$(dirname "$CUSTOM_CONFIG_FILENAME")"

cat > "$CUSTOM_CONFIG_FILENAME" <<EOF
QUANTUS_ARGS="--node-addr ${CUSTOM_URL} --auth-token ${CUSTOM_TEMPLATE} --metrics-port 9900 ${CUSTOM_USER_CONFIG}"
EOF
