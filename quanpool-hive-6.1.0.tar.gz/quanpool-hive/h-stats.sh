#!/usr/bin/env bash
# Report miner stats to HiveOS. Sourced by the agent — it must set $khs and
# $stats. The miner already serves the exact HiveOS `stats` object, so this just
# forwards it and sums the per-GPU hashrate.
stats=$(curl -s --max-time 3 http://127.0.0.1:9900/hive-stats)

if [[ -z $stats ]]; then
  khs=0
  stats="null"
else
  khs=$(echo "$stats" | jq -r '[.hs[]] | add // 0')
  [[ -z $khs || $khs == "null" ]] && khs=0
fi
